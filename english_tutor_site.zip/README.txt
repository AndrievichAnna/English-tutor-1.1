# Мини-сайт репетитора — развертывание на GitHub Pages

Этот архив содержит готовый `index.html` с встроенной Google Form (тест уровня A1–A2).
Замените контакты на свои и разверните сайт бесплатно через GitHub Pages.

---

## 1) Подготовьте аккаунт и репозиторий
1. Зарегистрируйтесь/войдите на https://github.com
2. Нажмите **+ → New repository**
3. Назовите репозиторий, например: `english-tutor`
4. Выберите **Public**
5. Нажмите **Create repository**

## 2) Загрузите файлы сайта
**Вариант через браузер:**
- Откройте репозиторий → **Add file → Upload files**
- Перетащите `index.html` (и этот `README.txt`, по желанию)
- Нажмите **Commit changes**

**Вариант через Git (по желанию):**
```bash
git clone https://github.com/ВАШ_ЛОГИН/english-tutor.git
cd english-tutor
# Скопируйте index.html в эту папку
git add .
git commit -m "Initial site"
git push
```

## 3) Включите GitHub Pages
1. Зайдите в **Settings → Pages**
2. В блоке **Source** выберите:
   - **Branch:** `main`
   - **Folder:** `/root`
3. Нажмите **Save**

Через ~1 минуту сайт будет доступен по адресу:
```
https://ВАШ_ЛОГИН.github.io/english-tutor/
```

## 4) Отредактируйте контакты
Откройте `index.html` и замените плейсхолдеры:
- `t.me/your_username` → ваш Telegram
- `wa.me/0000000000` → ваш WhatsApp (в формате международного номера без +)
- `you@example.com` → ваша почта
- `[Имя]` → ваше имя

(Можно редактировать прямо в GitHub: **Edit → Commit changes**.)

## 5) Изменить высоту формы (по желанию)
В `index.html` найдите блок:
```css
.form-wrap iframe{width:100%; height:4183px; border:none}
```
Уменьшите число, если форма получается слишком высокой, или увеличьте, если появляется прокрутка.

## 6) Проверка
- Откройте сайт по ссылке GitHub Pages.
- Пройдите тест и убедитесь, что ответы приходят в Google Forms/Google Sheets.

Готово! Ссылку на сайт можно размещать в соцсетях, рассылках и визитках.
